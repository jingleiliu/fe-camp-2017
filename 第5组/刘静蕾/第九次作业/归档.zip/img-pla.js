$("#BCY").click(function(){

})